---
name: countries-guesser-player
description: Play the "World Country Alliances Guesser" geography game (countriesguesser.com) against a human in friend mode. Use when the user sends a countriesguesser.com link containing `gameRoom=`, or asks you to play the countries/alliances/traps guessing game with them. You join their room in a browser with Playwright MCP only (no scripts), take turns guessing countries on the map, use clues and bonuses, chat, and report the result.
---

# Countries Guesser player (friend mode, Playwright only)

The human creates a game room and sends `https://www.countriesguesser.com?gameRoom=<8 chars>&allCountries=..&hints=..&time=..&bonus=..`.
You join as the guest, play a full game and tell the human how it went. No Python, no Node, no helper files: only Playwright MCP tools.

## Game in one paragraph
Each player secretly picks 8 alliances of border-connected countries (sizes 4,4,3,3,2,2,1,1, never touching each other) and 4 trap countries.
Players alternate guessing the opponent's countries by clicking the map. A hit on an alliance or bonus country gives an extra try; a miss, trap
or timeout passes the turn. A trap costs points and gives the *trap's owner* a clue. First to find all 8 alliances wins. Rules: `references/rules-and-scoring.md`.

## Fair-play rules (hard)
- Act like a human at a screen: page DOM and screenshots only. **Never** inspect network traffic, browser storage or the opponent's setup to learn their countries.
  Do not read image file names/URLs of clues; identify flags, outlines and photos by looking.
- Do not press Finish, Delete Game Room or reload mid-game unless the human asks (no resume).
- Never reveal your own countries in chat.

## Setup (before the game starts)
- **Check first:** if you have no `browser_navigate` / `browser_evaluate` tools (no Playwright MCP), install it before doing anything else, then tell the human
  if a restart or reconnect is needed.
  - Claude Code, macOS/Linux: `claude mcp add playwright -- npx -y @playwright/mcp@latest --headless --isolated` (then `/mcp` reconnect or restart).
  - Claude Code, Windows: `claude mcp add playwright -s user -- cmd /c npx -y @playwright/mcp@latest --headless --isolated`. `npx` is a `.cmd` file, so it
    needs the `cmd /c` wrapper. In Git Bash set `MSYS_NO_PATHCONV=1` first (or run it from PowerShell), or Git Bash rewrites `/c` to `C:/` and the server
    fails to connect.
  - Needs Node.js (`npx`). If Playwright is installed but without these flags, re-add it with them.
- `--headless`: the human cannot glimpse your picks, and a headless page is not throttled. `--isolated`: a fresh in-memory browser profile per session, so the
  game never restores an old page from `sessionStorage` or leaks into the human's own browser profile.
- `alert()`/`confirm()` dialogs block the next tool call: call `browser_handle_dialog` at once and tell the human what it said.
- **Second game in the same browser (rematch, new room link):** the page may reopen the previous room and show "Game room does not exist" again and again,
  and the new `browser_navigate` ends up on the old URL. Call `browser_handle_dialog`, then `browser_evaluate` `() => sessionStorage.clear()`, then navigate to the
  new link again (it can take one more round). If it keeps happening, close the browser with `browser_close` and navigate again for a clean start.
- Never call a full `browser_snapshot` during play (the map has ~200 markers). Use `browser_wait_for` text, `browser_take_screenshot`, or a small `browser_evaluate`.

## Procedure
1. `browser_navigate` to the exact link (settings travel in the query string). UI language must be English. `browser_wait_for` text "Opponent is online".
2. Join: click `#start-button`, then the dice `#gameCountryAllianceInitialSelectionRandomButton` (always legal), then the visible Play button. Several
   elements match `.guess-country-game-play`, so `browser_click` on it fails; use `browser_evaluate`:
   `() => { [...document.querySelectorAll('.guess-country-game-play')].find(e => e.getClientRects().length)?.click(); }`.
   If the banner says "Opponent has not yet selected countries", press Play again every ~4 s. Say hello in chat.
3. **Turn loop** until `#gameResultModal` opens. Wait for text "Your attempt to guess" (the opponent's turn can last up to the timer). If the wait times out, do not just wait again: in one `browser_evaluate` read
   `#gameResultModal` (`classList.contains('show')` = the game is over; the banner may still show the last move), the chat and the banner, and act on what changed
   (a slow opponent, a new chat hint, or the end of the game). Then pick a country
   with these rules, in this priority (details in `references/strategy.md`):
   1. **Highlighted countries** (after a super-bonus, see Bonus): these are certain alliance countries; guess them first.
   2. **Finish the open alliance**: after a hit whose alliance is not complete (banner shows a country, not "Country Alliance"), guess a still-clickable neighbour
      of the hit country (random if several; prefer one bordering several hits). Repeat until "Country Alliance" appears. Use your own geography knowledge for borders.
   3. **Clue**: if a clue is live, guess a still-clickable country that matches it (country/capital = that country; subregion/region = random match; flag/outline/photo =
      identify by sight). Drop the clue after you find a country it fits.
   4. **Otherwise random**, among clickable countries, skipping isolated ones (islands, or a pocket smaller than the smallest unfinished alliance) while alliances
      of size 2 or more remain. For neighbours, islands and clue matching (region, subregion, capital) read `data/countries.md` (the border table)
   instead of trusting memory; it is plain text, not a script. To see everything still in play, list the clickable countries with one expression (re-run it after
   a few turns, because the game removes countries on its own):
   `browser_evaluate` → `() => [...document.querySelectorAll('img.leaflet-marker-icon')].filter(m => m.style.opacity !== '0').map(m => m.alt).join(', ')`.
   Use it to find pockets big enough for the biggest unfinished alliance.
   **Before every guess check for a new clue** (a missed clue costs a turn): `#hints-link` visible, text of `#hints-panel-content` changed, or an
   open modal in `.modal.show`. If so, read it first (step 5). Keep the last panel text in `window.__lastPanel` and compare.
   Decide "alliance complete or still open" from `#player-two-countries-number` (opponent alliances left; it drops when one completes), **not** from the
   banner alone: a finished one-country alliance shows just the country name ("You guessed South Korea"), exactly like a plain hit, and the game then removes its
   neighbours from play (North Korea vanished). Read the counter after every hit before chasing neighbours.
   **Also check the chat** in the same call: read `#chat-message-from-opponent`.value (only the latest message is kept, prefixed "🧓: ") and compare it with
   `window.__lastChat`. A new message is from the human: a greeting, a joke, or their own hint about their countries. Answer briefly in chat (step 6) and use
   a hint as a strong but loose clue (step 5); never ask for hints. Examples: "Big country in Asia" suggests Kazakhstan, "two countries with
   Korea at the end" suggests the two Koreas, "Benelux" a whole 3-country alliance. Turn the hint into candidates, guess the likeliest, then continue with the
   neighbour rule. If the human asks for a clue about your own countries, decline politely and keep playing (never reveal them).
   `#gameResultHeading` / `#gameResultScore` hold the **previous** game's text until `#gameResultModal` is in `.modal.show`; only read them then.
   Click with one inline expression (typed in the call, not a stored script), and sample the banner while the page settles, because result banners
   flash for only ~1 s and one late read misses them:
   `browser_evaluate` → `async () => { const m = document.querySelector('img.leaflet-marker-icon[alt="France"]'); if (!m || m.style.opacity === "0") return "unavailable"; m.click(); const seen = []; for (let i = 0; i < 12; i++) { await new Promise(r => setTimeout(r, 300)); const t = document.querySelector('#countries-battle-game-message').innerText.replace(/\s+/g, ' ').trim(); if (seen.at(-1) !== t) seen.push(t); } return seen; }`
   (the `alt` is the English name; "unavailable" = out of play, often pruned next to a trap or finished alliance, sometimes with no visible reason: pick another, do not retry). Outcomes: "You guessed X" = hit,
   "You guessed Country Alliance" = alliance done, bonus banner = extra try; "Failed attempt", trap, "Time is up" = wait for the opponent
   (`browser_wait_for` text "Your attempt to guess"). Close `#gameCountryAllianceGuessedModal` (`#gameCountryAllianceGuessedCloseButton`) before the next guess.
   The timer restarts on every try. `#player-one-score-field` / `#player-two-score-field` and `#player-one-countries-number` / `#player-two-countries-number`
   (alliances left, mine / theirs) show the race.
   Keep a short list in your reply of hits, completed alliances and traps; do not trust map colours (see `references/ui-and-dom.md`).
4. **Bonus**: a banner "🎁 ...bonus-country" is just +10 and an extra try. A banner containing "💎 ... super bonus-country ... highlighted on map" highlights certain
   opponent countries (the first/fifth bonus highlights a whole alliance, the second-fourth a single country). Immediately `browser_take_screenshot`, read the blue
   highlighted countries by sight, and guess them (rule 3.1). Highlights are meaningful only right after that banner (untouched countries are blue too).
5. **Clues** (when the human steps on one of your traps): a green `#hints-link` "View Hint" button appears; click it. Text clues are lines in
   `#hints-panel-content` (`Subregion: Eastern Africa`). Image clues: click `#flag-link`, `#coat-of-arms-link`, `#country-outline-link` or `#country-photo-link`,
   screenshot, identify. The timer keeps running while a modal is open; the next click or `[data-bs-dismiss="modal"]` closes it. A clue modal may open by itself at
   the start of your turn (an outline modal sometimes does). The panel keeps only the latest clue, e.g. `Country: Namibia`, then later just the image button. Text clue
   "Country: X" is certain: guess X at once. Outline clue: read the shape and surrounding terrain in a screenshot, then name the country. In "Choose Hints" mode pick a type in `#user-hint-types-select` and press `#gameUserHintSelectionPlayButton`.
   Hints the human types in chat are a gift you may use as a strong but loose hint; never ask for hints.
6. **Chat** (brief): `#chat-button`, type in `#chat-message-to-opponent`, send with `#chat-message-to-opponent-button`; the human's last message is in
   `#chat-message-from-opponent` (`.value`). Check it every turn (see step 3), not only at the start: the human may write at any time, and the box opens by
   itself on a new message. Reply in a line or two, in the human's language if it is not English. Say goodbye before the last turns; the chat disappears
   when the game ends. Mention to the human in your final report anything they told you in chat that you acted on.
7. **Finish** (the chat is gone once the game ends, so say goodbye earlier): read `#gameResultHeading` and `#gameResultScore`, tell the human who won and the scores, and offer a rematch (both click `#gameResultPlayButton`).
   A rematch in the same room needs no new link and no navigation: stay on the page and click that button. If the human sends the same link again after the room was
   deleted or left, the page only shows "Game room does not exist": tell them a new room (and link) is needed.

## When something looks wrong
- Turn stuck on the opponent > ~5 s past the timer, unknown banner or modal: screenshot and read `references/ui-and-dom.md`.
- Connection lost for over a minute / "Opponent left": the game ends by itself; tell the human and offer a new room.
- Page frozen after a trap clue in "All Countries" mode: tell the human; a new room fixes it.
- A rejected click: re-read the banner first, never retry in a loop.

## Files
`data/countries.md` (countries, borders, subregions, capitals), `references/rules-and-scoring.md` (rules and scoring), `references/ui-and-dom.md` (selectors, banners, modals), `references/strategy.md` (guessing strategy).
