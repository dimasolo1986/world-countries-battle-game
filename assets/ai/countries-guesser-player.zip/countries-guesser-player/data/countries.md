# Countries, borders and clue data

One line per country, names as on the map markers (English):
`Name | I=independent / T=territory | Subregion | Capital | land neighbours`
In independent mode (194 countries) ignore T countries and any neighbour that is a T; Kosovo is only in all-countries mode. A country with no
neighbours in play is an island: only a 1-country alliance or a trap. Use it for neighbour guesses, island checks and region/subregion/capital clues.

Afghanistan | I | Southern Asia | Kabul | China, Iran, Pakistan, Tajikistan, Turkmenistan, Uzbekistan
Aland Islands | T | Northern Europe | Mariehamn | -
Albania | I | Southeast Europe | Tirana | Greece, Kosovo, Montenegro, North Macedonia
Algeria | I | Northern Africa | Algiers | Libya, Mali, Mauritania, Morocco, Niger, Tunisia, Western Sahara
American Samoa | T | Polynesia | Pago Pago | -
Andorra | I | Southern Europe | Andorra la Vella | France, Spain
Angola | I | Middle Africa | Luanda | DR Congo, Namibia, Republic of the Congo, Zambia
Anguilla | T | Caribbean | The Valley | -
Antarctica | T |  |  | -
Antigua and Barbuda | I | Caribbean | Saint John's | -
Argentina | I | South America | Buenos Aires | Bolivia, Brazil, Chile, Paraguay, Uruguay
Armenia | I | Western Asia | Yerevan | Azerbaijan, Georgia, Iran, Turkey
Aruba | T | Caribbean | Oranjestad | -
Australia | I | Australia and New Zealand | Canberra | -
Austria | I | Central Europe | Vienna | Czechia, Germany, Hungary, Italy, Liechtenstein, Slovakia, Slovenia, Switzerland
Azerbaijan | I | Western Asia | Baku | Armenia, Georgia, Iran, Russia, Turkey
Bahamas | I | Caribbean | Nassau | -
Bahrain | I | Western Asia | Manama | -
Bangladesh | I | Southern Asia | Dhaka | India, Myanmar
Barbados | I | Caribbean | Bridgetown | -
Belarus | I | Eastern Europe | Minsk | Latvia, Lithuania, Poland, Russia, Ukraine
Belgium | I | Western Europe | Brussels | France, Germany, Luxembourg, Netherlands
Belize | I | Central America | Belmopan | Guatemala, Mexico
Benin | I | Western Africa | Porto-Novo | Burkina Faso, Niger, Nigeria, Togo
Bermuda | T | North America | Hamilton | -
Bhutan | I | Southern Asia | Thimphu | China, India
Bolivia | I | South America | Sucre | Argentina, Brazil, Chile, Paraguay, Peru
Bosnia and Herzegovina | I | Southeast Europe | Sarajevo | Croatia, Montenegro, Serbia
Botswana | I | Southern Africa | Gaborone | Namibia, South Africa, Zambia, Zimbabwe
Bouvet Island | T |  |  | -
Brazil | I | South America | Brasília | Argentina, Bolivia, Colombia, French Guiana, Guyana, Paraguay, Peru, Suriname, Uruguay, Venezuela
British Indian Ocean Territory | T | Eastern Africa | Diego Garcia | -
British Virgin Islands | T | Caribbean | Road Town | -
Brunei | I | South-Eastern Asia | Bandar Seri Begawan | Malaysia
Bulgaria | I | Southeast Europe | Sofia | Greece, North Macedonia, Romania, Serbia, Turkey
Burkina Faso | I | Western Africa | Ouagadougou | Benin, Ghana, Ivory Coast, Mali, Niger, Togo
Burundi | I | Eastern Africa | Gitega | DR Congo, Rwanda, Tanzania
Cambodia | I | South-Eastern Asia | Phnom Penh | Laos, Thailand, Vietnam
Cameroon | I | Middle Africa | Yaoundé | Central African Republic, Chad, Equatorial Guinea, Gabon, Nigeria, Republic of the Congo
Canada | I | North America | Ottawa | United States
Cape Verde | I | Western Africa | Praia | -
Caribbean Netherlands | T | Caribbean | Kralendijk | -
Cayman Islands | T | Caribbean | George Town | -
Central African Republic | I | Middle Africa | Bangui | Cameroon, Chad, DR Congo, Republic of the Congo, South Sudan, Sudan
Chad | I | Middle Africa | N'Djamena | Cameroon, Central African Republic, Libya, Niger, Nigeria, Sudan
Chile | I | South America | Santiago | Argentina, Bolivia, Peru
China | I | Eastern Asia | Beijing | Afghanistan, Bhutan, Hong Kong, India, Kazakhstan, Kyrgyzstan, Laos, Macau, Mongolia, Myanmar, Nepal, North Korea, Pakistan, Russia, Tajikistan, Vietnam
Christmas Island | T | Australia and New Zealand | Flying Fish Cove | -
Cocos (Keeling) Islands | T | Australia and New Zealand | West Island | -
Colombia | I | South America | Bogotá | Brazil, Ecuador, Panama, Peru, Venezuela
Comoros | I | Eastern Africa | Moroni | -
Cook Islands | T | Polynesia | Avarua | -
Costa Rica | I | Central America | San José | Nicaragua, Panama
Croatia | I | Southeast Europe | Zagreb | Bosnia and Herzegovina, Hungary, Montenegro, Serbia, Slovenia
Cuba | I | Caribbean | Havana | -
Curaçao | T | Caribbean | Willemstad | -
Cyprus | I | Southern Europe | Nicosia | -
Czechia | I | Central Europe | Prague | Austria, Germany, Poland, Slovakia
Denmark | I | Northern Europe | Copenhagen | Germany
Djibouti | I | Eastern Africa | Djibouti | Eritrea, Ethiopia, Somalia
Dominica | I | Caribbean | Roseau | -
Dominican Republic | I | Caribbean | Santo Domingo | Haiti
DR Congo | I | Middle Africa | Kinshasa | Angola, Burundi, Central African Republic, Republic of the Congo, Rwanda, South Sudan, Tanzania, Uganda, Zambia
Ecuador | I | South America | Quito | Colombia, Peru
Egypt | I | Northern Africa | Cairo | Israel, Libya, Palestine, Sudan
El Salvador | I | Central America | San Salvador | Guatemala, Honduras
Equatorial Guinea | I | Middle Africa | Malabo | Cameroon, Gabon
Eritrea | I | Eastern Africa | Asmara | Djibouti, Ethiopia, Sudan
Estonia | I | Northern Europe | Tallinn | Latvia, Russia
Eswatini | I | Southern Africa | Mbabane | Mozambique, South Africa
Ethiopia | I | Eastern Africa | Addis Ababa | Djibouti, Eritrea, Kenya, Somalia, South Sudan, Sudan
Falkland Islands | T | South America | Stanley | -
Faroe Islands | T | Northern Europe | Tórshavn | -
Fiji | I | Melanesia | Suva | -
Finland | I | Northern Europe | Helsinki | Norway, Russia, Sweden
France | I | Western Europe | Paris | Andorra, Belgium, Germany, Italy, Luxembourg, Monaco, Spain, Switzerland
French Guiana | T | South America | Cayenne | Brazil, Suriname
French Polynesia | T | Polynesia | Papeetē | -
French Southern and Antarctic Lands | T |  | Port-aux-Français | -
Gabon | I | Middle Africa | Libreville | Cameroon, Equatorial Guinea, Republic of the Congo
Gambia | I | Western Africa | Banjul | Senegal
Georgia | I | Western Asia | Tbilisi | Armenia, Azerbaijan, Russia, Turkey
Germany | I | Western Europe | Berlin | Austria, Belgium, Czechia, Denmark, France, Luxembourg, Netherlands, Poland, Switzerland
Ghana | I | Western Africa | Accra | Burkina Faso, Ivory Coast, Togo
Gibraltar | T | Southern Europe | Gibraltar | Spain
Greece | I | Southern Europe | Athens | Albania, Bulgaria, North Macedonia, Turkey
Greenland | T | North America | Nuuk | -
Grenada | I | Caribbean | St. George's | -
Guadeloupe | T | Caribbean | Basse-Terre | -
Guam | T | Micronesia | Hagåtña | -
Guatemala | I | Central America | Guatemala City | Belize, El Salvador, Honduras, Mexico
Guernsey | T | Northern Europe | St. Peter Port | -
Guinea | I | Western Africa | Conakry | Guinea-Bissau, Ivory Coast, Liberia, Mali, Senegal, Sierra Leone
Guinea-Bissau | I | Western Africa | Bissau | Guinea, Senegal
Guyana | I | South America | Georgetown | Brazil, Suriname, Venezuela
Haiti | I | Caribbean | Port-au-Prince | Dominican Republic
Heard Island and McDonald Islands | T |  |  | -
Honduras | I | Central America | Tegucigalpa | El Salvador, Guatemala, Nicaragua
Hong Kong | T | Eastern Asia | City of Victoria | China
Hungary | I | Central Europe | Budapest | Austria, Croatia, Romania, Serbia, Slovakia, Slovenia, Ukraine
Iceland | I | Northern Europe | Reykjavik | -
India | I | Southern Asia | New Delhi | Bangladesh, Bhutan, China, Myanmar, Nepal, Pakistan
Indonesia | I | South-Eastern Asia | Jakarta | Malaysia, Papua New Guinea, Timor-Leste
Iran | I | Southern Asia | Tehran | Afghanistan, Armenia, Azerbaijan, Iraq, Pakistan, Turkey, Turkmenistan
Iraq | I | Western Asia | Baghdad | Iran, Jordan, Kuwait, Saudi Arabia, Syria, Turkey
Ireland | I | Northern Europe | Dublin | United Kingdom
Isle of Man | T | Northern Europe | Douglas | -
Israel | I | Western Asia | Jerusalem | Egypt, Jordan, Lebanon, Palestine, Syria
Italy | I | Southern Europe | Rome | Austria, France, San Marino, Slovenia, Switzerland, Vatican City
Ivory Coast | I | Western Africa | Yamoussoukro | Burkina Faso, Ghana, Guinea, Liberia, Mali
Jamaica | I | Caribbean | Kingston | -
Japan | I | Eastern Asia | Tokyo | -
Jersey | T | Northern Europe | Saint Helier | -
Jordan | I | Western Asia | Amman | Iraq, Israel, Palestine, Saudi Arabia, Syria
Kazakhstan | I | Central Asia | Astana | China, Kyrgyzstan, Russia, Turkmenistan, Uzbekistan
Kenya | I | Eastern Africa | Nairobi | Ethiopia, Somalia, South Sudan, Tanzania, Uganda
Kiribati | I | Micronesia | South Tarawa | -
Kosovo | T | Southeast Europe | Pristina | Albania, Montenegro, North Macedonia, Serbia
Kuwait | I | Western Asia | Kuwait City | Iraq, Saudi Arabia
Kyrgyzstan | I | Central Asia | Bishkek | China, Kazakhstan, Tajikistan, Uzbekistan
Laos | I | South-Eastern Asia | Vientiane | Cambodia, China, Myanmar, Thailand, Vietnam
Latvia | I | Northern Europe | Riga | Belarus, Estonia, Lithuania, Russia
Lebanon | I | Western Asia | Beirut | Israel, Syria
Lesotho | I | Southern Africa | Maseru | South Africa
Liberia | I | Western Africa | Monrovia | Guinea, Ivory Coast, Sierra Leone
Libya | I | Northern Africa | Tripoli | Algeria, Chad, Egypt, Niger, Sudan, Tunisia
Liechtenstein | I | Western Europe | Vaduz | Austria, Switzerland
Lithuania | I | Northern Europe | Vilnius | Belarus, Latvia, Poland, Russia
Luxembourg | I | Western Europe | Luxembourg | Belgium, France, Germany
Macau | T | Eastern Asia |  | China
Madagascar | I | Eastern Africa | Antananarivo | -
Malawi | I | Eastern Africa | Lilongwe | Mozambique, Tanzania, Zambia
Malaysia | I | South-Eastern Asia | Kuala Lumpur | Brunei, Indonesia, Thailand
Maldives | I | Southern Asia | Malé | -
Mali | I | Western Africa | Bamako | Algeria, Burkina Faso, Guinea, Ivory Coast, Mauritania, Niger, Senegal
Malta | I | Southern Europe | Valletta | -
Marshall Islands | I | Micronesia | Majuro | -
Martinique | T | Caribbean | Fort-de-France | -
Mauritania | I | Western Africa | Nouakchott | Algeria, Mali, Senegal, Western Sahara
Mauritius | I | Eastern Africa | Port Louis | -
Mayotte | T | Eastern Africa | Mamoudzou | -
Mexico | I | North America | Mexico City | Belize, Guatemala, United States
Micronesia | I | Micronesia | Palikir | -
Moldova | I | Eastern Europe | Chișinău | Romania, Ukraine
Monaco | I | Western Europe | Monaco | France
Mongolia | I | Eastern Asia | Ulan Bator | China, Russia
Montenegro | I | Southeast Europe | Podgorica | Albania, Bosnia and Herzegovina, Croatia, Kosovo, Serbia
Montserrat | T | Caribbean | Plymouth | -
Morocco | I | Northern Africa | Rabat | Algeria, Spain, Western Sahara
Mozambique | I | Eastern Africa | Maputo | Eswatini, Malawi, South Africa, Tanzania, Zambia, Zimbabwe
Myanmar | I | South-Eastern Asia | Naypyidaw | Bangladesh, China, India, Laos, Thailand
Namibia | I | Southern Africa | Windhoek | Angola, Botswana, South Africa, Zambia
Nauru | I | Micronesia | Yaren | -
Nepal | I | Southern Asia | Kathmandu | China, India
Netherlands | I | Western Europe | Amsterdam | Belgium, Germany
New Caledonia | T | Melanesia | Nouméa | -
New Zealand | I | Australia and New Zealand | Wellington | -
Nicaragua | I | Central America | Managua | Costa Rica, Honduras
Niger | I | Western Africa | Niamey | Algeria, Benin, Burkina Faso, Chad, Libya, Mali, Nigeria
Nigeria | I | Western Africa | Abuja | Benin, Cameroon, Chad, Niger
Niue | T | Polynesia | Alofi | -
Norfolk Island | T | Australia and New Zealand | Kingston | -
North Korea | I | Eastern Asia | Pyongyang | China, Russia, South Korea
North Macedonia | I | Southeast Europe | Skopje | Albania, Bulgaria, Greece, Kosovo, Serbia
Northern Mariana Islands | T | Micronesia | Saipan | -
Norway | I | Northern Europe | Oslo | Finland, Russia, Sweden
Oman | I | Western Asia | Muscat | Saudi Arabia, United Arab Emirates, Yemen
Pakistan | I | Southern Asia | Islamabad | Afghanistan, China, India, Iran
Palau | I | Micronesia | Ngerulmud | -
Palestine | T | Western Asia | Ramallah | Egypt, Israel, Jordan
Panama | I | Central America | Panama City | Colombia, Costa Rica
Papua New Guinea | I | Melanesia | Port Moresby | Indonesia
Paraguay | I | South America | Asunción | Argentina, Bolivia, Brazil
Peru | I | South America | Lima | Bolivia, Brazil, Chile, Colombia, Ecuador
Philippines | I | South-Eastern Asia | Manila | -
Pitcairn Islands | T | Polynesia | Adamstown | -
Poland | I | Central Europe | Warsaw | Belarus, Czechia, Germany, Lithuania, Russia, Slovakia, Ukraine
Portugal | I | Southern Europe | Lisbon | Spain
Puerto Rico | T | Caribbean | San Juan | -
Qatar | I | Western Asia | Doha | Saudi Arabia
Republic of the Congo | I | Middle Africa | Brazzaville | Angola, Cameroon, Central African Republic, DR Congo, Gabon
Réunion | T | Eastern Africa | Saint-Denis | -
Romania | I | Southeast Europe | Bucharest | Bulgaria, Hungary, Moldova, Serbia, Ukraine
Russia | I | Eastern Europe | Moscow | Azerbaijan, Belarus, China, Estonia, Finland, Georgia, Kazakhstan, Latvia, Lithuania, Mongolia, North Korea, Norway, Poland, Ukraine
Rwanda | I | Eastern Africa | Kigali | Burundi, DR Congo, Tanzania, Uganda
Saint Barthélemy | T | Caribbean | Gustavia | -
Saint Helena, Ascension and Tristan da Cunha | T | Western Africa | Jamestown | -
Saint Kitts and Nevis | I | Caribbean | Basseterre | -
Saint Lucia | I | Caribbean | Castries | -
Saint Martin | T | Caribbean | Marigot | Sint Maarten
Saint Pierre and Miquelon | T | North America | Saint-Pierre | -
Saint Vincent and the Grenadines | I | Caribbean | Kingstown | -
Samoa | I | Polynesia | Apia | -
San Marino | I | Southern Europe | City of San Marino | Italy
São Tomé and Príncipe | I | Middle Africa | São Tomé | -
Saudi Arabia | I | Western Asia | Riyadh | Iraq, Jordan, Kuwait, Oman, Qatar, United Arab Emirates, Yemen
Senegal | I | Western Africa | Dakar | Gambia, Guinea, Guinea-Bissau, Mali, Mauritania
Serbia | I | Southeast Europe | Belgrade | Bosnia and Herzegovina, Bulgaria, Croatia, Hungary, Kosovo, Montenegro, North Macedonia, Romania
Seychelles | I | Eastern Africa | Victoria | -
Sierra Leone | I | Western Africa | Freetown | Guinea, Liberia
Singapore | I | South-Eastern Asia | Singapore | -
Sint Maarten | T | Caribbean | Philipsburg | Saint Martin
Slovakia | I | Central Europe | Bratislava | Austria, Czechia, Hungary, Poland, Ukraine
Slovenia | I | Central Europe | Ljubljana | Austria, Croatia, Hungary, Italy
Solomon Islands | I | Melanesia | Honiara | -
Somalia | I | Eastern Africa | Mogadishu | Djibouti, Ethiopia, Kenya
South Africa | I | Southern Africa | Pretoria | Botswana, Eswatini, Lesotho, Mozambique, Namibia, Zimbabwe
South Georgia | T |  | King Edward Point | -
South Korea | I | Eastern Asia | Seoul | North Korea
South Sudan | I | Middle Africa | Juba | Central African Republic, DR Congo, Ethiopia, Kenya, Sudan, Uganda
Spain | I | Southern Europe | Madrid | Andorra, France, Gibraltar, Morocco, Portugal
Sri Lanka | I | Southern Asia | Sri Jayawardenepura Kotte | -
Sudan | I | Northern Africa | Khartoum | Central African Republic, Chad, Egypt, Eritrea, Ethiopia, Libya, South Sudan
Suriname | I | South America | Paramaribo | Brazil, French Guiana, Guyana
Svalbard and Jan Mayen | T | Northern Europe | Longyearbyen | -
Sweden | I | Northern Europe | Stockholm | Finland, Norway
Switzerland | I | Western Europe | Bern | Austria, France, Germany, Italy, Liechtenstein
Syria | I | Western Asia | Damascus | Iraq, Israel, Jordan, Lebanon, Turkey
Taiwan | T | Eastern Asia | Taipei | -
Tajikistan | I | Central Asia | Dushanbe | Afghanistan, China, Kyrgyzstan, Uzbekistan
Tanzania | I | Eastern Africa | Dodoma | Burundi, DR Congo, Kenya, Malawi, Mozambique, Rwanda, Uganda, Zambia
Thailand | I | South-Eastern Asia | Bangkok | Cambodia, Laos, Malaysia, Myanmar
Timor-Leste | I | South-Eastern Asia | Dili | Indonesia
Togo | I | Western Africa | Lomé | Benin, Burkina Faso, Ghana
Tokelau | T | Polynesia | Fakaofo | -
Tonga | I | Polynesia | Nuku'alofa | -
Trinidad and Tobago | I | Caribbean | Port of Spain | -
Tunisia | I | Northern Africa | Tunis | Algeria, Libya
Turkey | I | Western Asia | Ankara | Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Iran, Iraq, Syria
Turkmenistan | I | Central Asia | Ashgabat | Afghanistan, Iran, Kazakhstan, Uzbekistan
Turks and Caicos Islands | T | Caribbean | Cockburn Town | -
Tuvalu | I | Polynesia | Funafuti | -
Uganda | I | Eastern Africa | Kampala | DR Congo, Kenya, Rwanda, South Sudan, Tanzania
Ukraine | I | Eastern Europe | Kyiv | Belarus, Hungary, Moldova, Poland, Romania, Russia, Slovakia
United Arab Emirates | I | Western Asia | Abu Dhabi | Oman, Saudi Arabia
United Kingdom | I | Northern Europe | London | Ireland
United States | I | North America | Washington, D.C. | Canada, Mexico
United States Minor Outlying Islands | T | North America | Washington DC | -
United States Virgin Islands | T | Caribbean | Charlotte Amalie | -
Uruguay | I | South America | Montevideo | Argentina, Brazil
Uzbekistan | I | Central Asia | Tashkent | Afghanistan, Kazakhstan, Kyrgyzstan, Tajikistan, Turkmenistan
Vanuatu | I | Melanesia | Port Vila | -
Vatican City | I | Southern Europe | Vatican City | Italy
Venezuela | I | South America | Caracas | Brazil, Colombia, Guyana
Vietnam | I | South-Eastern Asia | Hanoi | Cambodia, China, Laos
Wallis and Futuna | T | Polynesia | Mata-Utu | -
Western Sahara | T | Northern Africa | El Aaiún | Algeria, Mauritania, Morocco
Yemen | I | Western Asia | Sana'a | Oman, Saudi Arabia
Zambia | I | Eastern Africa | Lusaka | Angola, Botswana, DR Congo, Malawi, Mozambique, Namibia, Tanzania, Zimbabwe
Zimbabwe | I | Southern Africa | Harare | Botswana, Mozambique, South Africa, Zambia
