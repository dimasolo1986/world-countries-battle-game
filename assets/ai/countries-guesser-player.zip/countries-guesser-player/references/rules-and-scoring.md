# Rules and scoring

If the published rules and what you observe in a game ever differ, trust what the game does.

## Setup
- 8 alliances per player, selected in this order: sizes 4, 4, 3, 3, 2, 2, 1, 1 (20 countries), then 4 trap countries.
- Countries in an alliance form one connected group over land borders. Different alliances must not touch (at least one other country between
  them). Trap countries may not touch alliances or other traps. An island (no neighbour in play) can only be a one-country alliance or a trap.
- Borders are land borders between countries in play. Only countries in play count: with "Independent Countries" (194) a dependent
  territory is not a neighbour; "All Countries" (250) includes them. Kosovo is not in the independent set. Australia, Japan, Cuba etc. are
  islands (39 islands in independent mode, 86 in all-countries mode).
- Bonus countries (0, 5, 7 or 10; chosen by the host at Play time): drawn from countries that are in nobody's alliance, trap or neighbourhood. Russia is
  excluded from random selection and from bonuses (but not from manual picks or guessing). The first five bonus countries are "super
  bonuses": hitting the 1st or 5th highlights a whole unguessed opponent alliance, hitting the 2nd, 3rd or 4th highlights one unguessed alliance
  country, shown in blue on the map (banner "...highlighted on map"). Highlighted countries are certain alliance countries.

## Turns
- The host moves first. A turn is one guess; the guesser keeps the turn (extra try) after a hit on an alliance country or a bonus country,
  and loses it after a miss, a trap or a timeout. Every try restarts the full timer (0 = no timer; options 15/30/45/60 s).
- The turn also passes if the timer runs out ("Time is up!"). The timer only runs when the opponent has pressed Play too.
- Both browsers work out the result of a guess on their own; there is no result message between them.

## Scores
| Event | Points |
|---|---|
| Complete an alliance of 4 / 3 / 2 / 1 countries | +15 / +25 / +35 / +50 (awarded when its last country is found) |
| Hit a bonus country | +10 and an extra try |
| Hit a trap | -10, then -20, -30, and -50 for the fourth and any later one (counted per player) |
| End of game | winner only: +10 for each of their own alliances the opponent never found |

## Winning
The first player to find **all 8** of the opponent's alliances wins the game, regardless of score. (The score is shown, and the human may care,
but the game ends on alliance count.)

## What the game rules out for you (candidate pool)
After each result the game removes countries from the clickable set, and those removals are safe deductions because such countries
cannot be an alliance country:
- a trap hit removes the trap and its neighbours;
- a completed alliance removes all neighbours of all its members;
- a bonus hit removes that country's neighbours;
- every guessed country (hit, miss, trap) is removed.
The clickable markers (opacity not 0) already reflect this.

## Clues
A clue goes to the owner of the trap that was hit and concerns **one random not-yet-guessed alliance country of the player who hit it**. The
types, in order of usefulness: country name (exact), capital (exact), flag/coat of arms/photo (identify by sight), outline (identify by shape),
subregion, region. Each player draws clue types without repeats until all are used. Configurable in the room: all, text only (country,
capital, region, subregion), visual only (flag, coat of arms, outline, photo), choose each time, or none.

## Good to know
- The default number of bonus countries in the room is 7.
- Each extra try restarts the whole timer rather than continuing the old one.
