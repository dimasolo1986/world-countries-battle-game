# UI and DOM reference

Selectors and texts for https://www.countriesguesser.com. If the page behaves differently from what is written here (the site may have been
updated), trust what you see on the screen.

## How the game is played
Friend mode runs directly between the two browsers. There is no server API and no game state to read, so the only thing you can use is the page
itself, like a human player.

## Share link
`https://www.countriesguesser.com?gameRoom=<8 letters/digits>&allCountries=<true|false>&hints=<all|text|visual|select|none>&time=<0|15|30|45|60>&bonus=<0|5|7|10>`
No token. The guest page reads these parameters and locks its own settings to them, so always open the exact link. `allCountries=false`
means only independent countries (194), `true` adds territories (250).

## Flow for the guest (the agent)
| Step | Action | Wait for |
|---|---|---|
| 1 | Open the link | `#opponent-connection-main-page-text` = "Opponent is online" (starts as "Checking Connection..."; the START handler is registered only after this async setup, so an earlier click does nothing) |
| 2 | Click `#start-button` | selection modal `#gameCountryAllianceInitialSelectionModal`, banner "Choose first alliance from four countries on map or click 🎲" |
| 3 | Click `#gameCountryAllianceInitialSelectionRandomButton` | banner "Press 'Play' to start game!" (the host side may read "Opponent selected countries. Press 'Play'..."); a `.guess-country-game-play` button ("🕹️ Play") becomes visible |
| 4 | Click the visible Play button: `[...document.querySelectorAll('.guess-country-game-play')].find(e => e.getClientRects().length)?.click()` | banner "Opponent is guessing your country..." (host starts) |

The random button picks 4,4,3,3,2,2,1,1 alliances plus 4 traps, always legal (connected, separated, islands only as singles or traps).
Manual picking exists (`#gameCountryAllianceInitialSelectionUserButton`, then click map markers; undo `#undo-user-countries-selection`, clear
`#clean-user-countries-selection`), but it is slower and not needed.

Pressing Play before the human has chosen their alliances does nothing but show "Opponent has not yet selected countries. Wait for the message to start the game.";
once they have, your banner changes to "Opponent selected countries. Press 'Play' to start game!" (not always: if both players pick at the same moment the
banner may keep the shorter text), so retry Play every few seconds rather than waiting for that wording. If the host presses Play before you, the host's turn
starts at once but without a timer, and their clicks answer "Opponent has not yet started game. Wait for the message to start."; your own Play
press then starts yours. Press Play as soon as it is available.

## Flow for the host (only if you ever create the room)
Main page: set `#gameMode` (range input) to 1 (Friend), click `#create-game-room-button` (opens the room page), optionally change the
config selects (`#only-independent-countries-select`, `#time-select`, `#hint-types-select`, `#bonus-countries-select`), click the second
"Create Game Room" button (no id; match by text), read `#roomIdInput.value`, press `#start-button-game-room` once the guest is online.

## Page layout during the game
- `#countries-battle-game-message` - the banner at the top. It doubles as the turn indicator:
  - `⚠️ Your attempt to guess opponent's country` - my turn, input accepted.
  - `ℹ️ Opponent is guessing your country...` - their turn.
  - Result banners, each on screen only about a second before a turn banner replaces it:
    - `🎯 You guessed <Country>` - hit on an alliance country (extra try).
    - `🎯 You guessed Country Alliance` - last country of an alliance found (extra try, modal opens).
    - `⛔ Failed attempt to guess country!` - miss; `⛔ Opponent failed to guess your country!` on the other side.
    - `💣 You have fallen into a trap-country <X>. The opponent gets a hint` - you hit a trap (turn passes). The owner's banner reads
      `💣 Opponent has fallen into a trap-country <X>. The opponent gets a hint`; the wording is misleading, the owner is the one who
      receives the clue (check the clue panel, not the wording).
    - `🎁 You have fallen into a bonus-country` / `💎 ... super bonus-country` - bonus (+10, extra try).
    - `Time is up! The attempt to guess the country passes to your opponent` - timeout.
- Counters: `#timer-field` (seconds, only on my turn), `#player-one-score-field` (me, text like "🏅 -10"),
  `#player-two-score-field`, `#player-one-countries-number` / `#player-two-countries-number` (alliances left to find, mine / opponent's),
  `#countries-number-field` ("Available Countries"), `#bonus-countries-number-field`, `#opponent-connection-text`.
- Chat: `#chat-button` toggles `#chat-container` (hidden by default); write in `#chat-message-to-opponent` (max 300 chars), send with
  `#chat-message-to-opponent-button` or Enter (the box clears). Incoming text lands in `#chat-message-from-opponent`, which is an `<input>`: read its
  `.value` (not `innerText`), prefixed "🧓: ", holding only the **latest** message, and the container opens by itself on the receiver. Remember the
  previous value to notice a new message.
- Finish/Rules buttons are on the map (`Finish` asks `confirm()` and ends the game for both).

## The two maps (read this before trusting any colour)
The page shows **one** board at a time:
- On **my turn** it is the **opponent map**: path colours are the results of my guesses.
- While **the opponent guesses** it is **my own map**: green and orange paths are my own secret alliances and traps, and `#countries-number-field`
  reads like a fresh game. The page flips back and forth on each turn.

So colours, markers and the candidate counter mean "what I know about them" only when the banner says "Your attempt...". My accumulated results are back
at the start of my next turn.

Path colours on the opponent map for countries **I guessed**: `green` partial hit, `red` countries of a completed alliance, `orange` trap,
`grey` miss, `purple` bonus. Untouched countries stay `#3388ff`, which is also the blue **super-bonus highlight**. Blue is therefore evidence only
right after a banner "...super bonus-country ... highlighted on map": then the highlighted countries are certain alliance countries (see rules).

**Colours are not a safe record of my guesses.** In real games, countries I never guessed showed colours: after a trap hit or a completed
alliance, some of the countries the game rules out appeared `orange`, `green` or `red`. A stray `red` group looks like a completed alliance and
the alliance count disagrees with `#player-two-countries-number`. So keep your own list of guesses and outcomes from the banners instead of reading paint. The
clickable-marker list (below) is reliable and agrees with `#countries-number-field`.

## Clicking countries
- Countries cannot be chosen from a list or search box. Each country is a Leaflet marker `img.leaflet-marker-icon` whose `alt` is the English
  country name, plus an SVG `path.<ISO2>` for its outline.
- Markers with `style.opacity === "0"` are out of play (guessed, or ruled out by the game). The others are exactly the legal guesses.
- `marker.click()` from JavaScript registers as a guess. Avoid touch emulation: hover also fires a click on touch devices.
- After a click the board is locked for roughly 1-4 s while animations run and both browsers confirm the move; a second click during that time is
  ignored: wait for the banner to settle (or ~3 s) before the next click.
- When an alliance is completed a modal `#gameCountryAllianceGuessedModal` opens (auto-hides after ~10 s; close button
  `#gameCountryAllianceGuessedCloseButton`); close it before the next guess.

## Clues
Sent when someone steps on a **trap**: the trap's **owner** receives a clue about one of the hitter's still-unguessed countries. A green
`#hints-link` button ("View Hint", `data-hints` = number of clues) appears on the map; the clue panel `#hints-panel-content` holds the clues and a
"Hide" button (`#hints-hide-button`). The clue type is random per trap hit (each type is used once per player until all are consumed).
- **Text clues** (modes All, Text, Choose) are lines `Header: value`: `Country: <name>`, `Capital: <city>`, `Region: <Europe|Americas|Africa|Asia|Oceania|Antarctic>`,
  `Subregion: <e.g. Eastern Africa, South-Eastern Asia>`. Values contain a non-breaking space after the colon. In `innerText` the panel's button labels run
  into the clue text ("View Country PhotoHide"); only lines of the form `Header: value` are clues.
- **Image clues** (modes All, Visual, Choose) are buttons inside the panel that work with `.click()` even while the panel looks collapsed:
  `#flag-link` ("View Flag"), `#coat-of-arms-link`, `#country-outline-link` ("View Country Outline"), `#country-photo-link` ("View Country Photo").
  Each opens a Bootstrap modal (`#flagModal`, `#coatOfArmsModal`, `#countryOutlineModal` with `#outlineMap`, `#countryPhotoModal` with its
  `#countryPhotoCloseButton`; all closable via `[data-bs-dismiss="modal"]`). The photo modal shows a real photograph and a Close and
  a Full Screen button. **The turn timer keeps counting while a clue modal is open.** Coat of arms and photo fall back to the flag when none exists.
  Click the button, then look at it with a screenshot. In a real game with a human host the photo and flag modals opened by themselves on the trap
  owner's turn, and the button stayed available afterwards, showing the same old clue if opened again: react only to a new trap hit.
- Mode "Choose Hints": the trap owner first gets `#gameUserHintSelectionModal` with `<select id="user-hint-types-select">` (values `country`, `flag`, `region`,
  `boundary`, `capital`, `subregion`, `emblem`, `photo`) and `#gameUserHintSelectionPlayButton`; the timer starts only after the choice.
- A clue describes one still-unguessed country; once you find a country that fits it (found after the clue arrived), consider it used.
- Mode "No Hints": no clue is given.

## End of game
`#gameResultModal` opens with `#gameResultHeading` ("👏 Congratulations! You won the game!" / "💔 Sorry, You lost the game..."),
`#gameResultScore`, `#gameResultGuessing`. `#gameResultCloseButton` closes it, `#gameResultPlayButton` starts a rematch (both players click it;
same room, the host moves first). The page loads the main screen behind the modal immediately after the result is shown, so the chat box is gone (writing to it fails) and
`#gameResultModal` lists the countries of the loser's side that the winner found.

## Dialogs and other traps
- `alert()` / `confirm()` appear for: room missing, connection failed, "Sorry... Opponent left the game.", game room deleted, and Finish.
  With Playwright MCP the next tool call is refused until `browser_handle_dialog` is called.
- If the connection drops, `#opponent-connection-text` / `#opponent-connection-indicator` change; after ~60 s without connection the game ends
  with an alert. There is no resume.
- A connection hiccup mid-game can tear the room down; nothing to do but start a new room.
- The connection between the players is not fully reliable: a lost move can stall the turn until the 60 s timer passes it.
- No captcha, login or consent popup. Language defaults to English and is stored in `localStorage.language`; the header selector
  `#language-selector` switches it. Non-English UIs localise banners and marker names, which breaks the helpers.
- Use a fresh browser profile or context per game: `sessionStorage.currentWindow` restores the last page.
- Possible freeze: in "All Countries" mode a clue request can loop forever when the chosen clue attribute is missing for that
  country (for example a territory without a capital).
