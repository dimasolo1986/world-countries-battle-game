# Strategy

Simple and effective: no probabilities, no solver.

## Priority on every try
1. **Certain countries**: countries highlighted by a super-bonus hit (a whole unguessed alliance, or one alliance country).
2. **Neighbours of an open hit**: after a hit on an unfinished alliance, guess the still-in-play neighbours of that country in random order until the
   alliance completes. The game removes neighbours of completed alliances and traps from play itself.
3. **Your own text clue** (from a trap the human stepped on): a random in-play country matching the clue (name, capital, region or subregion).
4. **Random viable country**: a random clickable country lying in a connected group (clickable + hit countries) at least as big as the smallest unfinished
   alliance. So islands and small pockets are skipped while alliances of size 2+ remain. Hot/cold hints are not used in friend mode.

Neighbours, islands and clue matches come from `data/countries.md`, the border table.

## Why this is enough
The real edges are clues and super-bonus highlights, which the rules above already use. More elaborate guessing gains very little.

## Tips (cheap, optional)
- Among several neighbours of a hit prefer one that also borders another hit (likely the same alliance); a hit group of size k needs an alliance larger than k.
- Large countries in dense regions host big alliances; islands can only be 1-country alliances or traps.
- Bonus countries sit away from alliances and traps; do not chase them.
- Never leak your own picks in chat. Dice-select your own setup (no information to exploit).
